#! /bin/bash


# Verificar si el traje ya está en la mochila
if [[ -f "$MOCHILA/$TRAJE" ]]; then
    echo "👔 ¡Ya llevas puesto el traje Thinra!"
    sleep 1
    echo "Te queda espectacular. Realmente pareces un Soldier primera class."
    sleep 1
    echo "✅ El traje ha sido añadido a tu mochila"
    # No hacer nada más, no vender otro traje
else
    # Vender el traje (copiar/crear el archivo)
    read -p "EL traje Thinra vale 50 Rupias. Quieres comprarlo? [S/N]" compra

    case $compra in
    S|s)
        echo "De acuerdo, es tuyo."
        sleep 1
        echo "🧥 Te lo pones y notas cómo te envuelve una sensación de poder."
        echo "50" > $Mochila/monedas
        touch $Mochila/traje_shinra
      ;;
    N|n)
        echo "Si te lo piensas mejor, aquí estoy."
      ;;
    *)
        echo "Debes introducir S ó N."
      ;;
    esac
  
fi





